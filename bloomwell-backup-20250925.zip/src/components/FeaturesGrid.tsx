export default function FeaturesGrid() {
  const features = [
    {
      icon: (
        <svg
          className='w-8 h-8 text-green-600'
          fill='none'
          stroke='currentColor'
          viewBox='0 0 24 24'
        >
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            strokeWidth={2}
            d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z'
          />
        </svg>
      ),
      title: '73,000+ Federal Grants',
      description:
        "Real-time database with automatic deadline tracking and AI-powered matching to your organization's mission",
    },
    {
      icon: (
        <svg
          className='w-8 h-8 text-blue-600'
          fill='none'
          stroke='currentColor'
          viewBox='0 0 24 24'
        >
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            strokeWidth={2}
            d='M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z'
          />
        </svg>
      ),
      title: 'Unlimited Chat & Projects',
      description:
        'AI-powered guidance with persistent project organization and unlimited conversation history',
    },
    {
      icon: (
        <svg
          className='w-8 h-8 text-purple-600'
          fill='none'
          stroke='currentColor'
          viewBox='0 0 24 24'
        >
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            strokeWidth={2}
            d='M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z'
          />
        </svg>
      ),
      title: 'All Webinars & Resources',
      description:
        'Live expert sessions plus downloadable worksheets, templates, and best practice guides',
    },
    {
      icon: (
        <svg
          className='w-8 h-8 text-orange-600'
          fill='none'
          stroke='currentColor'
          viewBox='0 0 24 24'
        >
          <path
            strokeLinecap='round'
            strokeLinejoin='round'
            strokeWidth={2}
            d='M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.25a9.75 9.75 0 100 19.5 9.75 9.75 0 000-19.5z'
          />
        </svg>
      ),
      title: 'Email Support & Training',
      description:
        'Dedicated nonprofit support team and comprehensive onboarding assistance',
    },
  ];

  return (
    <div className='text-center mb-16'>
      <h2 className='text-3xl md:text-4xl font-bold text-gray-900 mb-4'>
        Everything You Need to Secure Funding
      </h2>
      <p className='text-xl text-gray-600 max-w-2xl mx-auto mb-12'>
        Professional tools designed specifically for nonprofits under $3M budget
      </p>

      <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8'>
        {features.map((feature, index) => (
          <div
            key={index}
            className='bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow duration-300 group'
          >
            <div className='w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-green-50 transition-colors'>
              {feature.icon}
            </div>
            <h3 className='text-xl font-semibold text-gray-900 mb-4'>
              {feature.title}
            </h3>
            <p className='text-gray-600 leading-relaxed'>
              {feature.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
